<div class="form-content">
    <form action="" method="post">
        <textarea name="content" id="content" cols="30" rows="20"></textarea>
        <!-- Fake utilisateur pour rapidement démontrer le concept. -->
        <input type="text" name="user" value="1"> <!-- ID 1 => John Doe en base de données. -->
        <input type="submit" value="Ajouter article">
    </form>
</div>