<h1>Bienvenue sur ma super home page !</h1>
<span>Welcome <?= $var['user'] ?></span>

<div>
    <a href="/index.php?controller=articles">Consulter la liste de nos articles</a>
</div>